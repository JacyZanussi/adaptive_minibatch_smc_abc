This is the readme for source data supplied to Nature Computational Science for the article entitled: “Gene expression model inference from snapshot RNA data using Bayesian nonparametrics” by Zeliha Kilic, Max Schweiger, Camille Moyer, Douglas Shepherd, and Steve Pressé.

Where it occurs, in line code is used to compactly refer to the output of each command when executed in MATLAB.

Each figure’s source data consists of a single .zip file with directories associated to each independent MCMC run. Where figures consist of several MCMC runs, these folders are named after the value of the independent variable under investigation. Where figures consist only of a single MCMC run, this folder is called ‘panel’. 

Each of these directories contains two subdirectories.

1)’ ./data’ contains two .csv files: 
	a) data_times.csv : an ordered list of data collection times, recorded (arbitrarily) in seconds.
	b) rna_counds.csv : a 2D table of single cell RNA counts at the times given by data_times.csv, where each column contains 	counts collected at a different time.

2) ‘./results’ contains two .csv files:
	a) loads.csv : the most recently sampled set (each column being a distinct sample) of loads at each successive iteration.
	b) rates.csv: the most recently sampled set (each column being a distinct sample) of rates at each successive iteration. The 	identity of rates is in each row is as follows (for weak limit L):
		rates(1 : 2*nchoosek(L,2) , : )			:	transition rates, indexed according to idx = 		[nchoosek(1:L,2), fliplr(nchoosek(1:L,2))]. That is, the rate in position j corresponds to k_idx(j,1) -> idx(j,2), the 		transition rate from state idx(j,1) to state idx(j,2)
		rates(2*nchoosek(L,2)+1:2*nchoosek(L,2)_L , : )  :	transcription rates indexed from 1 to L
		rates(end,:) 					: 	the degradation rate



We have supplied all the data included in the figures. However, associated metadata is available upon request/
